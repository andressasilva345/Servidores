<?php

use App\Http\Controllers\AuthController;
use App\Http\Controllers\CommentController;
use App\Http\Controllers\UserController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('auth.login');
});

Route::get('/em-producao', function () {
    return view('inproduction');
});


Route::controller(AuthController::class)->group(function () {
    Route::get('login', 'loginPage')->name('login');
    Route::post('login', 'login')->name('login');

    Route::get('cadastrar', 'registerPage')->name('cadastrar');
    Route::post('cadastrar', 'register')->name('cadastrar');

    Route::get('logout', 'logout')->name('logout');
});


Route::middleware(['auth'])->group(function () {

    Route::get('/painel', function () {
        return view('painel', ['comments' => \App\Models\Comment::orderBy('created_at', 'DESC')->get()]);
    });


    Route::get('/contatos', function () {
        return view('contacts');
    });

    Route::controller(CommentController::class)->group(function () {
        Route::post('comentarios/novo', 'store')->name('comentarios.salvar');
        Route::post('comentarios/apagar/{comment}', 'destroy')->name('comentarios.apagar');
    });

    Route::controller(UserController::class)->group(function () {
        Route::get('usuarios/usuario', 'show')->name('usuario');
        Route::get('usuarios/usuario/editar', 'edit')->name('usuario.editar');
        Route::post('usuarios/usuario/atualizar', 'update')->name('usuario.atualizar');
        Route::get('usuarios/deletar/{usuario}', 'destroy')->name('usuario.apagar');
        // Route::get('usuarios/{user}','show')->name('usuario'); 
    });
});
