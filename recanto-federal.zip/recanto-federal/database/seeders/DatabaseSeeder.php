<?php

namespace Database\Seeders;

// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        \App\Models\Course::create(['name' => 'Eletrotécnica']);
        \App\Models\Course::create(['name' => 'Informática para Internet']);
        \App\Models\Course::create(['name' => 'Têxtil']);
        \App\Models\Course::create(['name' => 'Vestuário']);
        \App\Models\Course::create(['name' => 'Moda']);
    }
}
