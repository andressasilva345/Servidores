<!doctype html>
<html lang="en">

<head>
    <title>Em produção</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS v5.2.1 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">

</head>

<body>
    <div class="d-flex flex-column justify-content-center align-items-center ">
        <img src="<?php echo e(asset('in_production.jpg')); ?>" alt="" style="height: 300px; width:auto;">

        <div class="text-center">
            <span class="display-5">Serviço em produção</span>
        </div>

    </div>
</body>

</html>
<?php /**PATH C:\laragon\www\recanto-federal\resources\views/inproduction.blade.php ENDPATH**/ ?>