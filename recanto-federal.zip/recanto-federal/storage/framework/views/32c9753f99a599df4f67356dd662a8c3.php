

<?php $__env->startSection('conteudo'); ?>
    <main>
        <div class="container">

            <section class="section register min-vh-100 d-flex flex-column align-items-center justify-content-center py-4">
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-lg-4 col-md-6 d-flex flex-column align-items-center justify-content-center">

                            <div class="d-flex justify-content-center py-4">
                                <img src="<?php echo e(asset('assets/img/logo.JPEG')); ?>" style="width: 50px; height: 50px;">
                                <a href="index.html" class="logo d-flex align-items-center w-auto m-3">

                                    <span class="d-none d-lg-block ">Cadastro</span>
                                </a>
                            </div>

                            <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>

                            <div class="card mb-3">

                                <div class="card-body">

                                    <div class="pt-4 pb-2">
                                        <h5 class="card-title text-center pb-0 fs-4 ">Crie a sua conta</h5>
                                        <p class="text-center small">Insira seus dados pessoais para criar uma conta</p>
                                    </div>

                                    <form action="/cadastrar" method="POST" class="row g-3 needs-validation" novalidate>
                                        <?php echo csrf_field(); ?>
                                        <div class="col-6">
                                            <label for="yourName" class="form-label">Nome</label>
                                            <input type="text" name="name" class="form-control" value="<?php echo e(@old('name')); ?>" id="yourName"
                                                required>
                                            <div class="invalid-feedback">Por favor, coloque seu nome!</div>
                                        </div>

                                        <div class="col-6">
                                            <label for="yourName" class="form-label">Sobrenome</label>
                                            <input type="text" name="lastname" class="form-control" id="yourName" value="<?php echo e(@old('lastname')); ?>"
                                                required>
                                            <div class="invalid-feedback">Por favor, coloque seu sobrenome!</div>
                                        </div>

                                        <div class="col-12">
                                            <label for="yourEmail" class="form-label"> E-mail</label>
                                            <input type="email" name="email" class="form-control" id="yourEmail" value="<?php echo e(@old('email')); ?>"
                                                required>
                                            <div class="invalid-feedback">Por favor, coloque seu e-mail!</div>
                                        </div>

                                        <div class="col-6">
                                            <label for="yourPassword" class="form-label">Senha</label>
                                            <input type="password" name="password" class="form-control" id="yourPassword"
                                                required>
                                            <div class="invalid-feedback">Por favor, coloque seu senha!</div>
                                        </div>

                                        <div class="col-6">
                                            <label for="yourPassword" class="form-label">Confirmar Senha</label>
                                            <input type="password" name="password_confirmation" class="form-control"
                                                id="yourPassword" required>
                                            <div class="invalid-feedback">Por favor, confirme sua senha!</div>
                                        </div>

                                        <div class="mb-3">
                                            <label for="" class="form-label">Cursos</label>
                                            <select required class="form-select " name="course_id" id="">
                                                <?php echo e($courses = \App\Models\Course::all()); ?>

                                                <option value="">Selecione</option>
                                                <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($course->id); ?>"><?php echo e($course->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>

                                        <div class="col-12">
                                            <div class="form-check">
                                                <input class="form-check-input" name="terms" type="checkbox"
                                                    value="" id="acceptTerms" required>
                                                <label class="form-check-label" for="acceptTerms">Concordo e aceito os
                                                    termos e condições
                                            </div>
                                        </div>

                                </div>

                                <div class="col-12 d-flex justify-content-center">
                                    <button class="btn btn-success w-50 ">Entrar</button>
                                </div>
                                <div class="col-12">
                                    <p class="small p-3"> Tem uma conta? Conecte-se <a href="/login">Log in</a></p>
                                </div>
                                </form>

                            </div>
                        </div>

                    </div>
                </div>
        </div>

        </section>

        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\recanto-federal\resources\views/auth/cadastro.blade.php ENDPATH**/ ?>