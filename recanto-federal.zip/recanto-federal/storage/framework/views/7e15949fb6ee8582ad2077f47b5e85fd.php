
<?php $__env->startSection('content'); ?>
    <main>
        <div class="container">

            <section class="section register min-vh-100 d-flex flex-column align-items-center justify-content-center py-4">
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-lg-4 col-md-6 d-flex flex-column align-items-center justify-content-center">

                            <div class="card mt-5">
                                <div class="card-body " style="width: 100vh;">

                                    <div class="pt-4 pb-2">
                                        <h5 class="card-title text-center pb-0 fs-4 ">Edite seus dados</h5>
                                    </div>

                                    <form action="<?php echo e(url('/usuarios/usuario/atualizar')); ?>" method="POST"
                                        class="row g-3 needs-validation" novalidate>
                                        <?php echo csrf_field(); ?>
                                        <div class="col-6">
                                            <label for="yourName" class="form-label">Nome</label>
                                            <input type="text" name="name" class="form-control" required
                                                id="yourName" value= "<?php echo e(Auth::user()->name); ?>" required>
                                            <div class="invalid-feedback">Por favor, coloque seu nome!</div>
                                        </div>

                                        <div class="col-6">
                                            <label for="yourName" class="form-label">Sobrenome</label>
                                            <input type="text" name="lastname" class="form-control" required
                                                id="yourName" value= "<?php echo e(Auth::user()->lastname); ?>" required>
                                            <div class="invalid-feedback">Por favor, coloque seu sobrenome!</div>
                                        </div>

                                        <div class="col-6">
                                            <label for="yourName" class="form-label">País</label>
                                            <input type="text" name="country" class="form-control" id="yourName"
                                                required value= "<?php echo e(Auth::user()->country); ?> " required>
                                            <div class="invalid-feedback">Por favor, coloque seu país!</div>
                                        </div>

                                        <div class="col-6">
                                            <label for="yourName" class="form-label">Cidade</label>
                                            <input type="text" name="city" class="form-control" required
                                                id="yourName" value= "<?php echo e(Auth::user()->city); ?> " required>
                                            <div class="invalid-feedback">Por favor, coloque sua cidade!</div>
                                        </div>

                                        <div class="col-12">
                                            <label for="yourName" class="form-label">Endereço</label>
                                            <input type="text" name="address" class="form-control" id="yourName"
                                                required value= " <?php echo e(Auth::user()->address); ?>" required>
                                            <div class="invalid-feedback">Por favor, coloque seu endereço!</div>
                                        </div>

                                        <div class="col-12">
                                            <label for="yourName" class="form-label">Telefone</label>
                                            <input type="string" name="telephone" class="form-control" id="yourName"
                                                required value= "<?php echo e(Auth::user()->telephone); ?> " required>
                                            <div class="invalid-feedback">Por favor, coloque seu telefone!</div>
                                        </div>

                                        <div class="col-12">
                                            <label for="yourEmail" class="form-label"> E-mail</label>
                                            <input type="email" name="email" class="form-control" id="yourEmail"
                                                required value= "<?php echo e(Auth::user()->email); ?> " required>
                                            <div class="invalid-feedback">Por favor, coloque seu e-mail!</div>
                                        </div>

                                        <div class="mb-3">
                                            <label for="" class="form-label">Curso</label>
                                            <select required class="form-select " name="course" id="">
                                                <option selected value="<?php echo e(Auth::user()->course->id); ?>">
                                                    <?php echo e(Auth::user()->course->name); ?></option>

                                                <?php $__currentLoopData = \App\Models\Course::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($course->id); ?>"><?php echo e($course->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>

                                        <div class="col-12">
                                            <label for="yourEmail" class="form-label"> Sobre mim</label>
                                            <textarea name="about" class="form-control" required> <?php echo e(Auth::user()->about); ?></textarea>
                                            <div class="invalid-feedback">Por favor, coloque algo sobre você</div>
                                        </div>


                                        <div class="col-12 d-flex justify-content-center">
                                            <button class="btn btn-success w-50 " type="submit">Editar</button>
                                        </div>

                                    </form>

                                </div>
                            </div>

                        </div>
                    </div>
                </div>

            </section>

        </div>
    </main><!-- End #main -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\recanto-federal\resources\views/profile/edit.blade.php ENDPATH**/ ?>