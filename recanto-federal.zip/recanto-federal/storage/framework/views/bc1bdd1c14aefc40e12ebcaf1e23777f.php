<!DOCTYPE html>
<html lang="pt-br">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Recanto Federal</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

    <!-- Favicons -->
    <link href="<?php echo e(asset('assets/img/logo.jpeg')); ?>" rel="icon">
    <link href="<?php echo e(asset('assets/img/apple-touch-icon.png')); ?>" rel="apple-touch-icon">

    <!-- Google Fonts -->
    <link href="https://fonts.gstatic.com" rel="preconnect">
    <link
        href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i"
        rel="stylesheet">

    <!-- Vendor CSS Files -->
    <link href="<?php echo e(asset('assets/vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/vendor/bootstrap-icons/bootstrap-icons.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/vendor/boxicons/css/boxicons.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/vendor/quill/quill.snow.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/vendor/quill/quill.bubble.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/vendor/remixicon/remixicon.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/vendor/simple-datatables/style.css')); ?>" rel="stylesheet">

    <!-- Template Main CSS File -->
    <link href="<?php echo e(asset('assets/css/style.css')); ?>" rel="stylesheet">

</head>

<body>

  <header id="header" class="header fixed-top d-flex align-items-center">
    <img src="<?php echo e(asset('assets/img/logo.JPEG')); ?>" style="width: 50px; height: 50px;">

    <div class="d-flex align-items-center justify-content-between m-3" style="max-height: 15px">
      <a href="/painel" class="logo d-flex align-items-center">

        <span class="d-none d-lg-block ">Recanto Federal</span>
      </a>
      <i class="bi bi-list toggle-sidebar-btn"></i>
    </div><!-- End Logo -->


    <div class="search-bar ">
      <form class="search-form d-flex align-items-center" method="get" action="/em-producao">
        <input class="rounded-5" type="text" name="query" placeholder="Pesquisar" title="Enter search keyword">
        <button type="submit" title="Search"><i class="bi bi-search"></i></button>
      </form>
    </div><!-- End Search Bar -->

    <nav class="header-nav ms-auto">
      <ul class="d-flex align-items-center">

        <li class="nav-item d-block d-lg-none">
          <a class="nav-link nav-icon search-bar-toggle " href="#">
            <i class="bi bi-search"></i>
          </a>
        </li><!-- End Search Icon-->

        <li class="nav-item dropdown">

          <a class="nav-link nav-icon" href="#" data-bs-toggle="dropdown">
            <i class="bi bi-bell"></i>
            <span class="badge bg-primary badge-number">0</span>
          </a><!-- End Notification Icon -->

          <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow notifications">
            <li class="dropdown-header">
              Você não tem novas notificações
              <a href="/em-producao"><span class="badge rounded-pill bg-primary p-2 ms-2">Ver tudo</span></a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>
            <li>
            </li>
            <li class="dropdown-footer">
              <a href="/em-producao">Mostrar todas as notificações</a>
            </li>

          </ul><!-- End Notification Dropdown Items -->

        </li><!-- End Notification Nav -->

        <li class="nav-item dropdown">
          <a class="nav-link nav-icon" href="/em-producao" data-bs-toggle="dropdown">
            <i class="bi bi-chat-left-text"></i>
            <span class="badge bg-success badge-number">3</span>
          </a><!-- End Messages Icon -->

          <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow messages">
            <li class="dropdown-header">
              Você tem 3 novas notificações
              <a href="/em-producao"><span class="badge rounded-pill bg-primary p-2 ms-2">Ver tudo</span></a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li class="message-item">
              <a href="/em-producao">
                <img src="<?php echo e(asset('assets/img/icon_login.png')); ?>" alt="" class="rounded-circle">
                <div>
                  <h4>Wandson Guimarães</h4>
                  <p>E aí, meu chapa! Você viu a nova publicação de materiais do curso de Informática?
                    Os recursos parecem ser muito úteis para nós,
                    estudantes da área!</p>
                  <p>4 hrs. ago</p>
                </div>
              </a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li class="message-item">
              <a href="/em-producao">
                <img src="<?php echo e(('assets/img/icon_login.png')); ?>" alt="" class="rounded-circle">
                <div>
                  <h4>Kauã Bayron</h4>
                  <p>E ai meu consagrado como vai ? você viu a nova públição de material do curso de Eletrotécnica. Os matérias são ótimos... </p>
                  <p>2 hrs. ago</p>
                </div>
              </a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li class="message-item">
              <a href="/em-producao">
                <img src="<?php echo e(('assets/img/icon_login.png')); ?>" alt="" class="rounded-circle">
                <div>
                  <h4>Andressa Carla</h4>
                  <p>Olá amigo(a), Acabei de ver os materiais atualizados para os cursos de Vestuário e Têxtil eles vão me ajudar muito 📚👚...</p>
                  <p>8 hrs. ago</p>
                </div>
              </a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li class="dropdown-footer">
              <a href="/em-producao">Mostrar todas as notificações</a>
            </li>

          </ul>

        </li>

        <li class="nav-item dropdown pe-3">

          <a class="nav-link nav-profile d-flex align-items-center pe-0" href="/em-producao" data-bs-toggle="dropdown">
            <img src="<?php echo e(asset('assets/img/icon_login.png')); ?>" alt="Profile" class="rounded-circle">
            <span class="d-none d-md-block dropdown-toggle ps-2">
              <?php echo e(Auth::user()->name); ?>

            </span>
          </a>

          <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow profile">
            <li class="dropdown-header">
              <h6> <?php echo e(Auth::user()->name); ?></h6>
              <span><?php echo e(Auth::user()->course->name); ?></span>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li>
              <a class="dropdown-item d-flex align-items-center" href="/usuarios/usuario">
                <i class="bi bi-person"></i>
                <span>Meu Perfil</span>
              </a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li>
              <a class="dropdown-item d-flex align-items-center" href="/usuarios/usuario">
                <i class="bi bi-gear"></i>
                <span>Configuração</span>
              </a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li>
              <a class="dropdown-item d-flex align-items-center" href="/contatos">
                <i class="bi bi-question-circle"></i>
                <span>Ajuda</span>
              </a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li>
              <a class="dropdown-item d-flex align-items-center" href="/logout ">
                <i class="bi bi-box-arrow-right"></i>
                <span>Sair</span>
              </a>
            </li>

          </ul><!-- End Profile Dropdown Items -->
        </li><!-- End Profile Nav -->

      </ul>
    </nav><!-- End Icons Navigation -->

  </header><!-- End Header -->

  <!-- ======= Sidebar ======= -->

  <aside id="sidebar" class="sidebar">

    <ul class="sidebar-nav" id="sidebar-nav">

      <li class="nav-item">
        <a class="nav-link " href="/painel">
          <i class="bi bi-grid"></i>
          <span>Pagina inicial</span>
        </a>
      </li><!-- End Dashboard Nav -->

      <li class="nav-item">
        <a class="nav-link collapsed" data-bs-target="#components-nav" data-bs-toggle="collapse" href="">
          <i class="bi bi-menu-button-wide"></i><span>Materias</span><i class="bi bi-chevron-down ms-auto"></i>
        </a>
        <ul id="components-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
          <li>
            <a href="/em-producao">
              <i class="bi bi-circle"></i><span>PDFs</span>
            </a>
          </li>
          <li>
            <a href="/em-producao">
              <i class="bi bi-circle"></i><span>Livros</span>
            </a>
          </li>
          <li>
            <a href="/em-producao">
              <i class="bi bi-circle"></i><span>Video-Aulas</span>
            </a>
          </li>
        </ul>
      </li>

      <li class="nav-item">
        <a class="nav-link collapsed" data-bs-target="#forms-nav" data-bs-toggle="collapse" href="/em-producao">
          <i class="bi bi-journal-text"></i><span>Cursos</span><i class="bi bi-chevron-down ms-auto"></i>
        </a>
        <ul id="forms-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
          <li>
            <a href="/em-producao">
              <i class="bi bi-circle"></i><span>Informatica</span>
            </a>
          </li>
          <li>
            <a href="/em-producao">
              <i class="bi bi-circle"></i><span>Vestuário</span>
            </a>
          </li>
          <li>
            <a href="/em-producao">
              <i class="bi bi-circle"></i><span>Eletrotécnica</span>
            </a>
          </li>
          <li>
            <a href="/em-producao">
              <i class="bi bi-circle"></i><span>Têxtil</span>
            </a>
          </li>
        </ul>
      </li><!-- End Forms Nav -->

      <li class="nav-item">
        <a class="nav-link collapsed" data-bs-target="#tables-nav" data-bs-toggle="collapse" href="/em-producao">
          <i class="bi bi-layout-text-window-reverse"></i><span>Salas</span><i class="bi bi-chevron-down ms-auto"></i>
        </a>
        <ul id="tables-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
          <li>
            <a href="/em-producao">
              <i class="bi bi-circle"></i><span>Reservada-dúvida</span>
            </a>
          </li>
          <li>
            <a href="/em-producao">
              <i class="bi bi-circle"></i><span>C.A</span>
            </a>
          </li>
        </ul>
      </li><!-- End Tables Nav -->

      <li class="nav-item">
        <a class="nav-link collapsed" data-bs-target="#charts-nav" data-bs-toggle="collapse" href="/em-producao">
          <i class="bi bi-chat-dots"></i><span>Chats</span><i class="bi bi-chevron-down ms-auto"></i>
        </a>
        <ul id="charts-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
          <li>
            <a href="/em-producao">
              <i class="bi bi-circle"></i><span>Chat-Voz</span>
            </a>
          </li>
          <li>
            <a href="/em-producao">
              <i class="bi bi-circle"></i><span>Chat-Texto</span>
            </a>
          </li>

        </ul>
      </li><!-- End Charts Nav -->


      <li class="nav-heading">Dados</li>

      <li class="nav-item">
        <a class="nav-link collapsed" href="/usuarios/usuario">
          <i class="bi bi-person"></i>
          <span>Perfil</span>
        </a>
      </li><!-- End Profile Page Nav -->



      <li class="nav-item">
        <a class="nav-link collapsed" href="/contatos">
          <i class="bi bi-envelope"></i>
          <span>Contatos</span>
        </a>
      </li>


      </li>

      <li class="nav-item">
        <a class="nav-link collapsed" href="/logout">

          <i class="bi bi-box-arrow-in-right"></i>
          <span>Sair</span>
        </a>

    </ul>

  </aside><!-- End Sidebar-->

  <div>
      <?php echo $__env->yieldContent('content'); ?>
  </div>
  
  <!-- ======= Footer ======= -->
  <footer id="footer" class="footer">
    <div class="copyright">
      <strong><span>
          <p> © Copyright 2023 | Instituto Federal de Educação, Ciência e Tecnologia do Rio Grande do Norte</p>
        </span></strong>
    </div>

  </footer><!-- End Footer -->

  <a href="/em-producao" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="<?php echo e(asset('assets/vendor/apexcharts/apexcharts.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/vendor/chart.js/chart.umd.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/vendor/echarts/echarts.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/vendor/quill/quill.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/vendor/simple-datatables/simple-datatables.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/vendor/tinymce/tinymce.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/vendor/php-email-form/validate.js')); ?>"></script>


  <script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>

</body>

</html><?php /**PATH C:\laragon\www\recanto-federal\resources\views/layouts/layout.blade.php ENDPATH**/ ?>