<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;

class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(User $user)
    {
        return view('profile.profile');
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(User $user)
    {
        return view('profile.edit');
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'telephone' => 'integer',
        ]);
        if ($validator->fails()) {
            return back();
        } else {
            Auth::user()->update([
                'name' => $request->name,
                'lastname' => $request->lastname,
                'country' => $request->country,
                'email' => $request->email,
                'telephone' => $request->telephone,
                'city' => $request->city,
                'address' => $request->address,
                'course_id' => $request->course,
                'about' => $request->about,
            ]);
        }


        return back();
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(User $usuario, Request $request)
    {
        Auth::guard('web')->logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();

        $usuario->delete();
        return redirect(url('/'));
    }
}
